# OJ系统Docker容器化设计方案

## 1. 概述

本文档描述了在线评测系统(OJ)的Docker容器化设计方案，旨在提供一个简单、可靠、可扩展的部署方案，使系统能够在任何支持Docker的环境中轻松部署和运行。

### 1.1 设计目标

- **简化部署**：通过Docker容器化，简化系统部署流程，减少环境依赖问题
- **环境一致性**：确保开发、测试和生产环境的一致性
- **可扩展性**：支持水平扩展，以应对高并发场景
- **易于维护**：提供清晰的配置和日志管理，便于系统维护
- **安全隔离**：利用Docker的隔离特性，提高系统安全性

## 2. 容器架构

OJ系统将被拆分为多个容器，每个容器负责特定的功能，通过Docker网络进行通信。

### 2.1 容器组成

系统将包含以下容器：

1. **前端容器(oj-frontend)**
   - 基于Nginx镜像
   - 提供静态资源服务
   - 反向代理API请求到后端容器

2. **后端容器(oj-backend)**
   - 基于Python镜像
   - 运行Flask应用
   - 提供RESTful API服务

3. **数据库容器(oj-db)**
   - 基于PostgreSQL镜像
   - 存储系统数据
   - 提供数据持久化

4. **评测容器(oj-judge)**
   - 基于自定义镜像
   - 运行代码评测服务
   - 处理代码提交和评测

5. **Redis容器(oj-redis)**
   - 基于Redis镜像
   - 提供缓存服务
   - 支持任务队列

### 2.2 容器关系图

```
+----------------+       +----------------+       +----------------+
|                |       |                |       |                |
|  oj-frontend   | ----> |  oj-backend    | ----> |  oj-db         |
|  (Nginx)       |       |  (Flask)       |       |  (PostgreSQL)  |
|                |       |                |       |                |
+----------------+       +-------+--------+       +----------------+
                                 |
                                 v
                         +-------+--------+       +----------------+
                         |                |       |                |
                         |  oj-redis      | <---- |  oj-judge      |
                         |  (Redis)       |       |  (Custom)      |
                         |                |       |                |
                         +----------------+       +----------------+
```

## 3. 容器配置

### 3.1 前端容器(oj-frontend)

**基础镜像**：nginx:alpine

**配置文件**：
- nginx.conf：Nginx配置文件，包含反向代理设置
- default.conf：默认站点配置

**端口映射**：
- 容器内部端口：80
- 主机映射端口：80

**数据卷**：
- ./frontend/dist:/usr/share/nginx/html：前端静态资源
- ./frontend/nginx/nginx.conf:/etc/nginx/nginx.conf：Nginx配置文件
- ./frontend/nginx/default.conf:/etc/nginx/conf.d/default.conf：默认站点配置

### 3.2 后端容器(oj-backend)

**基础镜像**：python:3.11-slim

**配置文件**：
- .env：环境变量配置文件
- gunicorn.conf.py：Gunicorn配置文件

**端口映射**：
- 容器内部端口：5000
- 主机映射端口：5000

**数据卷**：
- ./backend:/app：后端应用代码
- ./backend/uploads:/app/uploads：上传文件目录

**环境变量**：
- FLASK_ENV=production
- DATABASE_URL=postgresql://postgres:postgres@oj-db:5432/oj
- REDIS_URL=redis://oj-redis:6379/0
- SECRET_KEY=your_secret_key

### 3.3 数据库容器(oj-db)

**基础镜像**：postgres:15-alpine

**端口映射**：
- 容器内部端口：5432
- 主机映射端口：5432

**数据卷**：
- ./data/postgres:/var/lib/postgresql/data：数据库数据

**环境变量**：
- POSTGRES_USER=postgres
- POSTGRES_PASSWORD=postgres
- POSTGRES_DB=oj

### 3.4 评测容器(oj-judge)

**基础镜像**：自定义镜像，基于python:3.11-slim

**配置文件**：
- judge.conf：评测系统配置文件

**数据卷**：
- ./judge:/app：评测系统代码
- ./judge/testcases:/app/testcases：测试用例目录

**环境变量**：
- BACKEND_URL=http://oj-backend:5000
- REDIS_URL=redis://oj-redis:6379/0

### 3.5 Redis容器(oj-redis)

**基础镜像**：redis:alpine

**端口映射**：
- 容器内部端口：6379
- 主机映射端口：6379

**数据卷**：
- ./data/redis:/data：Redis数据

## 4. 网络配置

系统将使用Docker自定义网络，所有容器将加入同一网络，以便相互通信。

**网络名称**：oj-network

**网络类型**：bridge

**容器网络配置**：
- oj-frontend：oj-network
- oj-backend：oj-network
- oj-db：oj-network
- oj-judge：oj-network
- oj-redis：oj-network

## 5. 数据持久化

系统将使用Docker数据卷进行数据持久化，确保容器重启或更新后数据不会丢失。

**数据卷配置**：
- ./data/postgres：PostgreSQL数据
- ./data/redis：Redis数据
- ./backend/uploads：上传文件
- ./judge/testcases：测试用例

## 6. 安全配置

### 6.1 容器安全

- 使用非root用户运行容器
- 限制容器资源使用
- 禁用不必要的容器功能
- 使用只读文件系统（适用时）

### 6.2 网络安全

- 只暴露必要的端口
- 使用内部网络进行容器间通信
- 配置反向代理，限制直接访问后端服务

### 6.3 数据安全

- 使用环境变量传递敏感信息
- 配置数据库访问权限
- 定期备份数据

## 7. 部署流程

### 7.1 前置条件

- 安装Docker（版本20.10.0或更高）
- 安装Docker Compose（版本2.0.0或更高）
- 至少2GB内存和10GB磁盘空间

### 7.2 部署步骤

1. 克隆代码仓库
2. 配置环境变量
3. 构建Docker镜像
4. 启动容器
5. 初始化数据库
6. 验证系统功能

### 7.3 命令示例

```bash
# 克隆代码仓库
git clone https://github.com/yourusername/oj-system.git
cd oj-system

# 配置环境变量
cp .env.example .env
# 编辑.env文件，设置必要的环境变量

# 构建Docker镜像
docker-compose build

# 启动容器
docker-compose up -d

# 初始化数据库
docker-compose exec oj-backend python init_db.py

# 验证系统功能
curl http://localhost
```

## 8. 监控与日志

### 8.1 日志配置

所有容器的日志将被收集并存储，便于问题排查和系统监控。

**日志配置**：
- 使用Docker日志驱动收集容器日志
- 配置日志轮转，避免日志文件过大
- 将关键日志输出到标准输出，便于集中收集

### 8.2 监控配置

系统将提供基本的监控功能，以便及时发现和解决问题。

**监控配置**：
- 使用Docker stats监控容器资源使用情况
- 配置健康检查，及时发现容器异常
- 提供API接口，用于外部监控系统集成

## 9. 扩展与优化

### 9.1 水平扩展

系统支持水平扩展，以应对高并发场景。

**扩展策略**：
- 前端容器：可以启动多个实例，通过负载均衡分发请求
- 后端容器：可以启动多个实例，通过负载均衡分发请求
- 评测容器：可以启动多个实例，通过任务队列分发评测任务

### 9.2 性能优化

系统提供了多种性能优化选项，以提高系统响应速度和吞吐量。

**优化选项**：
- 配置Nginx缓存，减少后端请求
- 使用Redis缓存热点数据
- 优化数据库查询，添加适当的索引
- 配置连接池，减少连接创建开销

## 10. 常见问题与解决方案

### 10.1 容器启动失败

**问题**：容器无法正常启动

**解决方案**：
- 检查Docker日志，查找错误信息
- 确认环境变量配置正确
- 检查端口是否被占用
- 确认数据卷权限设置正确

### 10.2 容器间通信问题

**问题**：容器之间无法正常通信

**解决方案**：
- 确认所有容器都加入了同一网络
- 检查容器名称解析是否正确
- 确认服务监听在正确的地址和端口
- 检查防火墙或安全组设置

### 10.3 数据持久化问题

**问题**：容器重启后数据丢失

**解决方案**：
- 确认数据卷配置正确
- 检查数据卷权限设置
- 确认使用了命名数据卷或绝对路径
- 定期备份重要数据

## 11. 结论

本文档提供了OJ系统的Docker容器化设计方案，包括容器架构、配置、网络、数据持久化、安全、部署流程、监控与日志、扩展与优化以及常见问题与解决方案。通过Docker容器化，可以简化系统部署流程，确保环境一致性，提高系统可扩展性和可维护性。

