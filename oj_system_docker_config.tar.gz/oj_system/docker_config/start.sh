#!/bin/bash

# 显示彩色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== OJ系统启动脚本 ===${NC}"

# 检查Docker是否安装
if ! command -v docker &> /dev/null; then
    echo -e "${RED}错误: Docker未安装，请先安装Docker${NC}"
    exit 1
fi

# 检查Docker Compose是否安装
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}错误: Docker Compose未安装，请先安装Docker Compose${NC}"
    exit 1
fi

# 创建必要的目录
echo -e "${YELLOW}创建数据目录...${NC}"
mkdir -p data/{postgres,redis,uploads,testcases,judge_temp}

# 检查环境变量文件
if [ ! -f docker/backend/.env ]; then
    echo -e "${YELLOW}后端环境变量文件不存在，正在从示例文件创建...${NC}"
    if [ -f docker/backend/.env.example ]; then
        cp docker/backend/.env.example docker/backend/.env
        echo -e "${GREEN}已创建后端环境变量文件，请根据需要修改${NC}"
    else
        echo -e "${RED}错误: 后端环境变量示例文件不存在${NC}"
        exit 1
    fi
fi

if [ ! -f docker/judge/.env ]; then
    echo -e "${YELLOW}评测系统环境变量文件不存在，正在从示例文件创建...${NC}"
    if [ -f docker/judge/.env.example ]; then
        cp docker/judge/.env.example docker/judge/.env
        echo -e "${GREEN}已创建评测系统环境变量文件，请根据需要修改${NC}"
    else
        echo -e "${RED}错误: 评测系统环境变量示例文件不存在${NC}"
        exit 1
    fi
fi

# 构建Docker镜像
echo -e "${YELLOW}构建Docker镜像...${NC}"
docker-compose build

# 启动容器
echo -e "${YELLOW}启动容器...${NC}"
docker-compose up -d

# 等待容器启动
echo -e "${YELLOW}等待容器启动...${NC}"
sleep 10

# 初始化数据库
echo -e "${YELLOW}初始化数据库...${NC}"
docker-compose exec -T oj-backend python docker/backend/init_db.py

echo -e "${GREEN}=== OJ系统已启动 ===${NC}"
echo -e "${GREEN}前端访问地址: http://localhost${NC}"
echo -e "${GREEN}后端API地址: http://localhost/api${NC}"
echo -e "${GREEN}默认管理员账号: admin / admin123${NC}"
echo -e "${YELLOW}请立即修改默认管理员密码!${NC}"

