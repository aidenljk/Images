# OJ系统 - 在线评测系统

一个功能完善的在线评测系统(OJ)，包含前后端、管理面板、用户权限管理等功能。系统采用现代化的设计风格，界面时尚美观大气，提供了良好的用户体验。

## 功能特点

- **用户管理**：注册、登录、个人资料管理、权限控制
- **题目管理**：题目列表、题目详情、题目分类与标签
- **代码提交与评测**：在线代码编辑器、多语言支持、实时评测
- **竞赛系统**：创建竞赛、参与竞赛、竞赛排行榜
- **讨论区**：发表讨论、回复评论、点赞功能
- **管理后台**：用户管理、题目管理、竞赛管理、系统设置

## 技术栈

- **前端**：React、Vite、TailwindCSS、shadcn/ui组件库
- **后端**：Flask、SQLAlchemy、Flask-JWT-Extended
- **数据库**：SQLite（开发环境）、PostgreSQL（生产环境）
- **评测系统**：自定义评测引擎，支持多种编程语言
- **部署**：Docker、Docker Compose

## 快速开始

### 使用Docker部署（推荐）

1. 确保已安装Docker和Docker Compose

```bash
# 检查Docker版本
docker --version

# 检查Docker Compose版本
docker-compose --version
```

2. 克隆代码仓库

```bash
git clone https://github.com/yourusername/oj-system.git
cd oj-system
```

3. 使用启动脚本启动系统

```bash
# 添加执行权限
chmod +x start.sh

# 启动系统
./start.sh
```

4. 访问系统

- 前端：http://localhost
- 后端API：http://localhost/api
- 默认管理员账号：admin / admin123

5. 停止系统

```bash
./stop.sh
```

### 手动部署

如果您不想使用Docker，也可以手动部署系统：

1. 部署后端

```bash
cd backend/oj_backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

2. 部署前端

```bash
cd frontend/oj_frontend
npm install
npm run dev
```

详细的手动部署说明请参考[后端README](backend/oj_backend/README.md)和[前端README](frontend/oj_frontend/README.md)。

## 项目结构

```
oj_system/
├── docker-compose.yml        # Docker Compose配置文件
├── start.sh                  # 启动脚本
├── stop.sh                   # 停止脚本
├── docker/                   # Docker配置目录
├── frontend/                 # 前端代码
├── backend/                  # 后端代码
└── data/                     # 数据目录（自动创建）
```

## Docker部署详细说明

详细的Docker部署说明请参考[Docker部署指南](docker/README.md)。

## 开发指南

### 后端开发

1. 进入后端目录

```bash
cd backend/oj_backend
```

2. 创建虚拟环境

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
```

3. 安装依赖

```bash
pip install -r requirements.txt
```

4. 运行开发服务器

```bash
python src/main.py
```

### 前端开发

1. 进入前端目录

```bash
cd frontend/oj_frontend
```

2. 安装依赖

```bash
npm install
```

3. 运行开发服务器

```bash
npm run dev
```

## 贡献指南

1. Fork本仓库
2. 创建您的特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交您的更改 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 打开一个Pull Request

## 许可证

本项目采用MIT许可证 - 详情请参见[LICENSE](LICENSE)文件。

## 联系方式

如有问题或需要支持，请联系：

- 邮箱：support@example.com
- GitHub Issues：https://github.com/yourusername/oj-system/issues

