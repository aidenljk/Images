#!/bin/bash
set -e

# 等待数据库启动
echo "Waiting for database..."
python /app/docker/backend/init_db.py

# 启动Gunicorn
echo "Starting Gunicorn..."
exec gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 120 src.main:app

