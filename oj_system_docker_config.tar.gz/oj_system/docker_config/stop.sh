#!/bin/bash

# 显示彩色输出
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}=== 停止OJ系统 ===${NC}"

# 检查Docker Compose是否安装
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}错误: Docker Compose未安装，请先安装Docker Compose${NC}"
    exit 1
fi

# 停止容器
echo -e "${YELLOW}停止容器...${NC}"
docker-compose down

echo -e "${GREEN}=== OJ系统已停止 ===${NC}"

