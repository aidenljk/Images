#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
from dotenv import load_dotenv

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# 加载环境变量
load_dotenv()

# 等待数据库启动
def wait_for_db():
    from sqlalchemy import create_engine
    from sqlalchemy.exc import OperationalError
    
    db_url = os.getenv('DATABASE_URL')
    if not db_url:
        print("ERROR: DATABASE_URL environment variable not set")
        sys.exit(1)
    
    engine = create_engine(db_url)
    
    max_retries = 30
    retry_interval = 2
    
    for i in range(max_retries):
        try:
            connection = engine.connect()
            connection.close()
            print("Database connection successful")
            return True
        except OperationalError:
            print(f"Waiting for database... {i+1}/{max_retries}")
            time.sleep(retry_interval)
    
    print("ERROR: Could not connect to database")
    return False

# 初始化数据库
def init_db():
    from src.models import db, User, Role, init_db as init_models
    from src.main import app
    
    with app.app_context():
        # 创建所有表
        db.create_all()
        
        # 初始化角色
        admin_role = Role.query.filter_by(name='admin').first()
        if not admin_role:
            admin_role = Role(name='admin', description='Administrator')
            db.session.add(admin_role)
        
        user_role = Role.query.filter_by(name='user').first()
        if not user_role:
            user_role = Role(name='user', description='Regular user')
            db.session.add(user_role)
        
        problem_setter_role = Role.query.filter_by(name='problem_setter').first()
        if not problem_setter_role:
            problem_setter_role = Role(name='problem_setter', description='Problem setter')
            db.session.add(problem_setter_role)
        
        # 创建管理员用户
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@example.com',
                is_active=True
            )
            admin_user.set_password('admin123')
            admin_user.roles.append(admin_role)
            db.session.add(admin_user)
        
        # 提交更改
        db.session.commit()
        
        print("Database initialized successfully")
        print("Admin user created: admin / admin123")

if __name__ == '__main__':
    if wait_for_db():
        init_db()

