#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import uuid
import subprocess
import shutil
import psutil
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import redis

# 加载环境变量
load_dotenv()

app = Flask(__name__)
CORS(app)

# 配置
JUDGE_PORT = int(os.getenv('JUDGE_PORT', 5001))
JUDGE_API_TOKEN = os.getenv('JUDGE_API_TOKEN', 'default_token')
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
MAX_EXECUTION_TIME = int(os.getenv('MAX_EXECUTION_TIME', 10))
MAX_MEMORY_USAGE = int(os.getenv('MAX_MEMORY_USAGE', 256))  # MB
TESTCASE_DIR = os.getenv('TESTCASE_DIR', '/app/testcases')
TEMP_DIR = os.getenv('TEMP_DIR', '/app/temp')

# 连接Redis
redis_client = redis.from_url(REDIS_URL)

# 支持的语言
LANGUAGES = {
    'python': {
        'extension': 'py',
        'compile_cmd': None,
        'run_cmd': ['python', '{filename}']
    },
    'cpp': {
        'extension': 'cpp',
        'compile_cmd': ['g++', '-std=c++17', '-O2', '-Wall', '{filename}', '-o', '{executable}'],
        'run_cmd': ['./{executable}']
    },
    'java': {
        'extension': 'java',
        'compile_cmd': ['javac', '{filename}'],
        'run_cmd': ['java', '-cp', '.', '{classname}']
    },
    'javascript': {
        'extension': 'js',
        'compile_cmd': None,
        'run_cmd': ['node', '{filename}']
    }
}

# 验证API Token
def verify_token():
    token = request.headers.get('Authorization')
    if not token or token != f'Bearer {JUDGE_API_TOKEN}':
        return False
    return True

# 创建临时目录
def create_temp_dir():
    temp_dir = os.path.join(TEMP_DIR, str(uuid.uuid4()))
    os.makedirs(temp_dir, exist_ok=True)
    return temp_dir

# 保存代码到文件
def save_code_to_file(code, language, temp_dir):
    extension = LANGUAGES[language]['extension']
    filename = f'solution.{extension}'
    filepath = os.path.join(temp_dir, filename)
    
    with open(filepath, 'w') as f:
        f.write(code)
    
    return filename, filepath

# 编译代码
def compile_code(language, filepath, temp_dir):
    if language not in LANGUAGES:
        return False, 'Unsupported language'
    
    compile_cmd = LANGUAGES[language]['compile_cmd']
    if not compile_cmd:
        return True, None
    
    filename = os.path.basename(filepath)
    executable = filename.split('.')[0]
    
    cmd = [c.format(filename=filename, executable=executable) for c in compile_cmd]
    
    try:
        process = subprocess.run(
            cmd,
            cwd=temp_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30
        )
        
        if process.returncode != 0:
            return False, process.stderr.decode('utf-8')
        
        return True, None
    except subprocess.TimeoutExpired:
        return False, 'Compilation timed out'
    except Exception as e:
        return False, str(e)

# 运行代码
def run_code(language, filepath, input_data, temp_dir):
    if language not in LANGUAGES:
        return False, 'Unsupported language', None, None
    
    filename = os.path.basename(filepath)
    executable = filename.split('.')[0]
    classname = executable
    
    cmd = [c.format(filename=filename, executable=executable, classname=classname) for c in LANGUAGES[language]['run_cmd']]
    
    input_file = os.path.join(temp_dir, 'input.txt')
    with open(input_file, 'w') as f:
        f.write(input_data)
    
    try:
        start_time = time.time()
        process = subprocess.Popen(
            cmd,
            cwd=temp_dir,
            stdin=open(input_file, 'r'),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # 监控资源使用
        max_memory = 0
        while process.poll() is None:
            try:
                p = psutil.Process(process.pid)
                memory_info = p.memory_info()
                memory_mb = memory_info.rss / (1024 * 1024)
                max_memory = max(max_memory, memory_mb)
                
                if memory_mb > MAX_MEMORY_USAGE:
                    process.kill()
                    return False, 'Memory limit exceeded', None, max_memory
                
                if time.time() - start_time > MAX_EXECUTION_TIME:
                    process.kill()
                    return False, 'Time limit exceeded', None, max_memory
                
                time.sleep(0.1)
            except psutil.NoSuchProcess:
                break
        
        stdout, stderr = process.communicate(timeout=MAX_EXECUTION_TIME)
        execution_time = time.time() - start_time
        
        if process.returncode != 0:
            return False, stderr.decode('utf-8'), execution_time, max_memory
        
        return True, stdout.decode('utf-8'), execution_time, max_memory
    except subprocess.TimeoutExpired:
        process.kill()
        return False, 'Execution timed out', MAX_EXECUTION_TIME, max_memory
    except Exception as e:
        return False, str(e), None, None

# 评测代码
def judge_submission(submission_id, code, language, problem_id):
    # 创建临时目录
    temp_dir = create_temp_dir()
    
    try:
        # 保存代码到文件
        filename, filepath = save_code_to_file(code, language, temp_dir)
        
        # 编译代码
        compile_success, compile_error = compile_code(language, filepath, temp_dir)
        if not compile_success:
            return {
                'submission_id': submission_id,
                'status': 'compilation_error',
                'compile_error': compile_error,
                'test_cases': []
            }
        
        # 获取测试用例
        testcase_dir = os.path.join(TESTCASE_DIR, str(problem_id))
        if not os.path.exists(testcase_dir):
            return {
                'submission_id': submission_id,
                'status': 'internal_error',
                'error': 'Test cases not found',
                'test_cases': []
            }
        
        # 读取测试用例
        test_cases = []
        for i in range(1, 100):  # 最多支持99个测试用例
            input_file = os.path.join(testcase_dir, f'{i}.in')
            output_file = os.path.join(testcase_dir, f'{i}.out')
            
            if not os.path.exists(input_file) or not os.path.exists(output_file):
                break
            
            with open(input_file, 'r') as f:
                input_data = f.read()
            
            with open(output_file, 'r') as f:
                expected_output = f.read().strip()
            
            test_cases.append({
                'input': input_data,
                'expected_output': expected_output
            })
        
        if not test_cases:
            return {
                'submission_id': submission_id,
                'status': 'internal_error',
                'error': 'No test cases found',
                'test_cases': []
            }
        
        # 运行测试用例
        results = []
        passed_count = 0
        total_time = 0
        max_memory = 0
        
        for i, test_case in enumerate(test_cases):
            success, output, execution_time, memory_usage = run_code(
                language, filepath, test_case['input'], temp_dir
            )
            
            if not success:
                status = 'runtime_error'
                if 'Memory limit exceeded' in output:
                    status = 'memory_limit_exceeded'
                elif 'Time limit exceeded' in output:
                    status = 'time_limit_exceeded'
                
                results.append({
                    'test_case': i + 1,
                    'status': status,
                    'runtime': execution_time,
                    'memory': memory_usage,
                    'input': test_case['input'],
                    'expected_output': test_case['expected_output'],
                    'actual_output': output
                })
                continue
            
            # 比较输出
            actual_output = output.strip()
            if actual_output == test_case['expected_output']:
                status = 'accepted'
                passed_count += 1
            else:
                status = 'wrong_answer'
            
            results.append({
                'test_case': i + 1,
                'status': status,
                'runtime': execution_time,
                'memory': memory_usage,
                'input': test_case['input'],
                'expected_output': test_case['expected_output'],
                'actual_output': actual_output
            })
            
            total_time += execution_time
            max_memory = max(max_memory, memory_usage or 0)
        
        # 确定最终状态
        if passed_count == len(test_cases):
            final_status = 'accepted'
        else:
            # 找出第一个失败的测试用例的状态
            for result in results:
                if result['status'] != 'accepted':
                    final_status = result['status']
                    break
            else:
                final_status = 'unknown_error'
        
        return {
            'submission_id': submission_id,
            'status': final_status,
            'passed_test_cases': passed_count,
            'total_test_cases': len(test_cases),
            'runtime': round(total_time * 1000, 2),  # 转换为毫秒
            'memory': round(max_memory, 2),
            'test_cases': results
        }
    finally:
        # 清理临时目录
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)

@app.route('/api/judge', methods=['POST'])
def judge():
    if not verify_token():
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.json
    if not data:
        return jsonify({'error': 'Invalid request'}), 400
    
    required_fields = ['submission_id', 'code', 'language', 'problem_id']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    submission_id = data['submission_id']
    code = data['code']
    language = data['language']
    problem_id = data['problem_id']
    
    if language not in LANGUAGES:
        return jsonify({'error': f'Unsupported language: {language}'}), 400
    
    # 将评测任务加入队列
    task_id = str(uuid.uuid4())
    task_data = {
        'submission_id': submission_id,
        'code': code,
        'language': language,
        'problem_id': problem_id,
        'status': 'pending',
        'created_at': time.time()
    }
    
    redis_client.set(f'judge:task:{task_id}', json.dumps(task_data))
    redis_client.lpush('judge:queue', task_id)
    
    return jsonify({
        'task_id': task_id,
        'status': 'pending'
    })

@app.route('/api/judge/status/<task_id>', methods=['GET'])
def judge_status(task_id):
    if not verify_token():
        return jsonify({'error': 'Unauthorized'}), 401
    
    task_data = redis_client.get(f'judge:task:{task_id}')
    if not task_data:
        return jsonify({'error': 'Task not found'}), 404
    
    task_data = json.loads(task_data)
    return jsonify(task_data)

def process_judge_queue():
    while True:
        # 从队列中获取任务
        task_id = redis_client.brpop('judge:queue', timeout=1)
        if not task_id:
            time.sleep(1)
            continue
        
        task_id = task_id[1].decode('utf-8')
        task_data = redis_client.get(f'judge:task:{task_id}')
        if not task_data:
            continue
        
        task_data = json.loads(task_data)
        task_data['status'] = 'judging'
        redis_client.set(f'judge:task:{task_id}', json.dumps(task_data))
        
        # 评测代码
        result = judge_submission(
            task_data['submission_id'],
            task_data['code'],
            task_data['language'],
            task_data['problem_id']
        )
        
        # 更新任务状态
        task_data.update(result)
        task_data['completed_at'] = time.time()
        redis_client.set(f'judge:task:{task_id}', json.dumps(task_data))
        
        # 设置过期时间（1小时）
        redis_client.expire(f'judge:task:{task_id}', 3600)

if __name__ == '__main__':
    # 确保测试用例目录存在
    os.makedirs(TESTCASE_DIR, exist_ok=True)
    
    # 启动评测队列处理线程
    import threading
    judge_thread = threading.Thread(target=process_judge_queue)
    judge_thread.daemon = True
    judge_thread.start()
    
    # 启动Flask应用
    app.run(host='0.0.0.0', port=JUDGE_PORT)

