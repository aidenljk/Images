# OJ系统Docker部署指南

本文档提供了使用Docker部署OJ系统的详细步骤和说明。

## 1. 系统要求

- Docker 20.10.0或更高版本
- Docker Compose 2.0.0或更高版本
- 至少2GB内存和10GB磁盘空间
- 互联网连接（用于拉取Docker镜像）

## 2. 目录结构

```
oj_system/
├── docker-compose.yml        # Docker Compose配置文件
├── docker/                   # Docker配置目录
│   ├── frontend/             # 前端Docker配置
│   │   ├── Dockerfile        # 前端Dockerfile
│   │   └── nginx/            # Nginx配置
│   │       ├── nginx.conf    # Nginx主配置
│   │       └── default.conf  # Nginx站点配置
│   ├── backend/              # 后端Docker配置
│   │   ├── Dockerfile        # 后端Dockerfile
│   │   ├── .env              # 后端环境变量
│   │   ├── init_db.py        # 数据库初始化脚本
│   │   └── entrypoint.sh     # 启动脚本
│   ├── judge/                # 评测系统Docker配置
│   │   ├── Dockerfile        # 评测系统Dockerfile
│   │   ├── .env              # 评测系统环境变量
│   │   ├── requirements.txt  # 评测系统依赖
│   │   └── judge/            # 评测系统代码
│   │       └── judge_server.py # 评测系统服务器
│   └── README.md             # 部署说明文档
├── data/                     # 数据目录（自动创建）
│   ├── postgres/             # PostgreSQL数据
│   ├── redis/                # Redis数据
│   ├── uploads/              # 上传文件
│   ├── testcases/            # 测试用例
│   └── judge_temp/           # 评测临时文件
├── frontend/                 # 前端代码
└── backend/                  # 后端代码
```

## 3. 快速开始

### 3.1 克隆代码仓库

```bash
git clone https://github.com/yourusername/oj-system.git
cd oj-system
```

### 3.2 配置环境变量

1. 后端环境变量

```bash
# 复制示例配置文件
cp docker/backend/.env.example docker/backend/.env

# 编辑配置文件
nano docker/backend/.env
```

2. 评测系统环境变量

```bash
# 复制示例配置文件
cp docker/judge/.env.example docker/judge/.env

# 编辑配置文件
nano docker/judge/.env
```

### 3.3 创建数据目录

```bash
mkdir -p data/{postgres,redis,uploads,testcases,judge_temp}
```

### 3.4 构建和启动容器

```bash
# 构建Docker镜像
docker-compose build

# 启动容器
docker-compose up -d
```

### 3.5 初始化数据库

```bash
# 初始化数据库
docker-compose exec oj-backend python docker/backend/init_db.py
```

### 3.6 访问系统

系统启动后，可以通过以下地址访问：

- 前端：http://localhost
- 后端API：http://localhost/api

默认管理员账号：
- 用户名：admin
- 密码：admin123

## 4. 配��说明

### 4.1 前端配置

前端配置主要在`docker/frontend/nginx/`目录下：

- `nginx.conf`：Nginx主配置文件
- `default.conf`：Nginx站点配置文件

如果需要修改前端API地址，可以编辑`docker/frontend/Dockerfile`中的环境变量：

```dockerfile
# 创建生产环境变量文件
RUN echo "VITE_API_URL=http://localhost/api" > .env.production
```

### 4.2 后端配置

后端配置主要在`docker/backend/.env`文件中，包括：

- 数据库连接
- Redis连接
- JWT配置
- CORS配置
- 应用配置
- 评测系统配置

### 4.3 评测系统配置

评测系统配置主要在`docker/judge/.env`文件中，包括：

- 评测系统端口
- API令牌
- Redis连接
- 后端API配置
- 评测配置

### 4.4 数据库配置

数据库配置在`docker-compose.yml`文件中：

```yaml
oj-db:
  image: postgres:15-alpine
  container_name: oj-db
  restart: unless-stopped
  environment:
    POSTGRES_USER: postgres
    POSTGRES_PASSWORD: postgres
    POSTGRES_DB: oj
  volumes:
    - ./data/postgres:/var/lib/postgresql/data
  networks:
    - oj-network
```

## 5. 常见问题

### 5.1 容器启动失败

**问题**：容器无法正常启动

**解决方案**：
- 检查Docker日志：`docker-compose logs`
- 确认环境变量配置正确
- 检查端口是否被占用
- 确认数据卷权限设置正确

### 5.2 前端路由问题

**问题**：刷新页面时出现404错误

**解决方案**：
- 确认Nginx配置中包含以下设置：
  ```
  location / {
      try_files $uri $uri/ /index.html;
  }
  ```

### 5.3 登录和注册问题

**问题**：无法登录或注册

**解决方案**：
- 检查后端API是否正常运行：`docker-compose logs oj-backend`
- 确认数据库连接正确：`docker-compose exec oj-backend python -c "from src.models import db; print(db.engine.url)"`
- 检查CORS配置是否正确
- 确认前端API地址配置正确

### 5.4 评测系统问题

**问题**：代码评测失败

**解决方案**：
- 检查评测系统日志：`docker-compose logs oj-judge`
- 确认Redis连接正确
- 检查测试用例目录权限
- 确认评测系统API令牌配置正确

## 6. 数据备份

### 6.1 数据库备份

```bash
# 备份数据库
docker-compose exec oj-db pg_dump -U postgres oj > backup.sql

# 恢复数据库
cat backup.sql | docker-compose exec -T oj-db psql -U postgres oj
```

### 6.2 文件备份

```bash
# 备份上传文件
tar -czvf uploads_backup.tar.gz data/uploads

# 备份测试用例
tar -czvf testcases_backup.tar.gz data/testcases
```

## 7. 系统更新

### 7.1 更新代码

```bash
# 拉取最新代码
git pull

# 重新构建镜像
docker-compose build

# 重启容器
docker-compose down
docker-compose up -d
```

### 7.2 数据库迁移

如果数据库结构有变化，需要执行迁移：

```bash
# 执行数据库迁移
docker-compose exec oj-backend python -c "from src.models import db; db.create_all()"
```

## 8. 性能优化

### 8.1 Nginx优化

可以修改`docker/frontend/nginx/nginx.conf`文件，调整以下参数：

- `worker_processes`：设置为CPU核心数
- `worker_connections`：根据内存大小调整
- `keepalive_timeout`：调整长连接超时时间
- `client_max_body_size`：调整上传文件大小限制

### 8.2 数据库优化

可以修改`docker-compose.yml`文件，为PostgreSQL添加配置：

```yaml
oj-db:
  image: postgres:15-alpine
  container_name: oj-db
  restart: unless-stopped
  environment:
    POSTGRES_USER: postgres
    POSTGRES_PASSWORD: postgres
    POSTGRES_DB: oj
    # 数据库优化参数
    POSTGRES_INITDB_ARGS: "--data-checksums"
  command: postgres -c shared_buffers=256MB -c max_connections=200
  volumes:
    - ./data/postgres:/var/lib/postgresql/data
  networks:
    - oj-network
```

### 8.3 后端优化

可以修改`docker/backend/entrypoint.sh`文件，调整Gunicorn参数：

```bash
# 启动Gunicorn
echo "Starting Gunicorn..."
exec gunicorn --bind 0.0.0.0:5000 --workers 4 --threads 2 --worker-class gevent --timeout 120 src.main:app
```

## 9. 安全配置

### 9.1 更改默认密码

首次部署后，请立即更改默认管理员密码：

1. 登录系统：http://localhost
2. 使用默认账号登录：admin / admin123
3. 进入个人设置页面
4. 更改密码

### 9.2 配置HTTPS

如果需要配置HTTPS，可以修改`docker/frontend/nginx/default.conf`文件：

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name yourdomain.com;
    
    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    
    # 其他配置...
}
```

然后修改`docker-compose.yml`文件，添加SSL证书卷：

```yaml
oj-frontend:
  build:
    context: .
    dockerfile: ./docker/frontend/Dockerfile
  container_name: oj-frontend
  restart: unless-stopped
  ports:
    - "80:80"
    - "443:443"
  volumes:
    - ./ssl:/etc/nginx/ssl
  depends_on:
    - oj-backend
  networks:
    - oj-network
```

## 10. 生产环境部署

对于生产环境部署，建议进行以下额外配置：

1. 使用外部数据库服务，如AWS RDS或阿里云RDS
2. 配置HTTPS
3. 设置自动备份
4. 配置监控和告警
5. 使用容器编排工具，如Kubernetes
6. 配置负载均衡器
7. 使用CDN加速静态资源

## 11. 联系与支持

如有问题或需要支持，请联系：

- 邮箱：support@example.com
- GitHub Issues：https://github.com/yourusername/oj-system/issues

